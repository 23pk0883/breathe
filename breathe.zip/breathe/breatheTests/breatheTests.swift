//
//  breatheTests.swift
//  breatheTests
//
//  Created by Sumrudhi Jadhav on 10/24/20.
//  Copyright © 2020 Team Sumja. All rights reserved.
//

import XCTest
@testable import breathe

class breatheTests: XCTestCase {

    //MARK: Mindfulness Class Tests
    
    // Confirm that the Mindfulness initializer returns a Mindfulness object when passed valid parameters.
    func testMindfulnessInitializationSucceeds() {
        
        // Zero rating
        let zeroRatingMindfulness = Mindfulness.init(name: "Zero", photo: nil, rating: 0)
        XCTAssertNotNil(zeroRatingMindfulness)

        // Positive rating
        let positiveRatingMindfulnessl = Mindfulness.init(name: "Positive", photo: nil, rating: 5)
        XCTAssertNotNil(positiveRatingMindfulnessl)

    }
    
    // Confirm that the Meal initialier returns nil when passed a negative rating or an empty name.
    func testMindfulnessInitializationFails() {
        
        // Negative rating
        let negativeRatingMindfulness = Mindfulness.init(name: "Negative", photo: nil, rating: -1)
        XCTAssertNil(negativeRatingMindfulness)
        
        // Rating exceeds maximum
        let largeRatingMindfulness = Mindfulness.init(name: "Large", photo: nil, rating: 6)
        XCTAssertNil(largeRatingMindfulness)

        // Empty String
        let emptyStringMindfulness = Mindfulness.init(name: "", photo: nil, rating: 0)
        XCTAssertNil(emptyStringMindfulness)
        
    }

}
